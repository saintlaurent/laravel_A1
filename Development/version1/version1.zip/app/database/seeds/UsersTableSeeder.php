<?php

class UsersTableSeeder extends Seeder
{
    public function run()
    {
        
    }
}